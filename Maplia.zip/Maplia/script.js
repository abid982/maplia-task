//////////////////////////////////
// Make mobile navigation work

// 'nav-open'

// btn-mobile-nav
const btnNavEl = document.querySelector('.btn-mobile-nav');
const headerEl = document.querySelector('.header');
console.log(btnNavEl);

btnNavEl.addEventListener('click', function () {
  headerEl.classList.toggle('nav-open');
});

// Carousel Slider
const buttons = document.querySelectorAll('[data-carousel-button]');

buttons.forEach(button => {
  button.addEventListener('click', () => {
    const offset = button.dataset.carouselButton === 'next' ? 1 : -1;
    const slides = button
      .closest('[data-carousel]')
      .querySelector('[data-slides]');

    const activeSlide = slides.querySelector('[data-active]');
    let newIndex = [...slides.children].indexOf(activeSlide) + offset;
    if (newIndex < 0) newIndex = slides.children.length - 1;
    if (newIndex >= slides.children.length) newIndex = 0;

    slides.children[newIndex].dataset.active = true;
    delete activeSlide.dataset.active;
  });
});

// Sticky
const sectionHeroEl = document.querySelector('.section-hero');
const nav = document.querySelector('.main-nav');
const header = document.querySelector('.header');

// Calculate root margin dynamically for responsive website
const navHeight = nav.getBoundingClientRect().height;
console.log(navHeight);

const stickyNav = function (entries, observer) {
  const [entry] = entries;
  console.log(entry);

  if (!entry.isIntersecting) {
    // false
    // Display sticky navigation
    // header.classList.add('sticky');
    header.classList.add('sticky');

    // sectionHeroEl.style.marginTop = `${navHeight}px`;
  } else {
    // header.classList.remove('sticky');
    header.classList.remove('sticky');
  }
};

// Create a new intersection header observer
const headerObserver = new IntersectionObserver(stickyNav, {
  root: null,
  threshold: 0,
  // threshold: 0.2, // 0% of the header is visible,

  // Calculate height dynamically
  // rootMargin: `${-navHeight}px`, // It's work no matter how small or how larger the viewport actually is
  rootMargin: '-80px',

  // Note: There are two great examples with Intersection Observer API coming up
});

// Use header observer to observe header target
headerObserver.observe(sectionHeroEl);
